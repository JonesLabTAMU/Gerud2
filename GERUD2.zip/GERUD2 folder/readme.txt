GERUD2.0 and GERUDsim2.0 - programs for the reconstruction of parental genotypes 
from progeny arrays

Adam G. Jones
email: ajones@mail.bio.tamu.edu

The GERUD package is made up of several files.  GERUD2.exe and GERUDsim2.exe are 
the program files.  Simply double click on the icon to run the program.  Two 
additional files, borlndmm.dll and cc3250mt.dll, are necessary for the GERUD 
programs to run.  These files should be in the same folder as GERUD2.exe and 
GERUDsim2.exe.

The Microsoft Word file, GERUD2manual.doc, describes the use of GERUD2.0 and 
GERUDsim2.0.  Four sample progeny array files, FCST9motherknown.txt, FCST9motherunknown.txt,FCST11motherknown.txt and 
FCST11motherunknown.txt, are included.  These are suitable for analysis using 
GERUD2.0.  TyphAlleleFrequencies.txt is a sample allele frequency file of the 
type used by both GERUD2.0 and GERUDsim2.0.

GERUD2.0 and GERUDsim2.0 are the first release versions of these programs.  
While I have tested the programs fairly extensively, they may still contain 
bugs.  If any unusual behavior is noted from either program, please contact me 
by email.
